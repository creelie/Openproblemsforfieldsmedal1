Zero-Free Criteria from Signed Liouville Energies
Research revision v2.8.1

Compile main.tex with pdfLaTeX at least three times.
Release: https://github.com/creelie/Openproblemsforfieldsmedal1/releases/tag/v2.8.1
Version DOI: https://doi.org/10.5281/zenodo.24045618
