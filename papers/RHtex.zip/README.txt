Compile main.tex with pdfLaTeX at least three times.
Research revision v2.8.0. The full conjecture remains open.
Ancillary scripts check only the finite claims described in their headers.
