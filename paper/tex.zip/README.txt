Compile main.tex with pdfLaTeX (three passes).
A multipole theorem bounds the normalized Liouville energy from below by a sum of pole contributions. A positive Fejer weight and a certified finite calculation give an unconditional limsup lower bound strictly greater than 3257/5000. RH and Dirichlet GRH remain open.
