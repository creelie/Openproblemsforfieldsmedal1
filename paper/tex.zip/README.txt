Compile main.tex with pdfLaTeX, three passes.
The complete manuscript incorporates a fixed deterministic completely multiplicative construction with all logarithmic savings and maximal Abel vanishing but an energy exponent 2 max(Theta,beta), plus rigidity of the exact Abel coefficient. RH and GRH remain open.
The release source tree contains earlier computational and formal-verification materials with their original scope.
