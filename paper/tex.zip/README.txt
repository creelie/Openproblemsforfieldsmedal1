Compile main.tex with pdfLaTeX, three passes.
The complete manuscript retains the earlier arguments and adds an exact coprime decomposition, a one-sided primitive-correlation criterion, the sharp signed dilation norm and its low-frequency behavior, and the conductor-one lifting calculation. It includes the quantitative Abel-jet obstruction and all earlier appendices. The critical upper estimate and the Riemann and generalized Riemann hypotheses remain unproved.
The release source tree contains earlier computational and formal-verification materials with their original scope.
