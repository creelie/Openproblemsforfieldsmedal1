Compile main.tex with pdfLaTeX (three passes).
Complete expanded v2.2.0 research revision, including v1 mathematics with corrections.
RH and Dirichlet GRH remain unproved.
Figures are exact constructions, not certified Liouville data.
Lean files and original v1 supplement are linked in the repository and full research ZIP.
Repository: https://github.com/creelie/Openproblemsforfieldsmedal1
